<div id="new_button">
    <a href="<?php echo Yii::app()->request->baseUrl . '/supplier'; ?>" class="none new">Supplier</a> 
    <a href="<?php echo Yii::app()->request->baseUrl . '/supplier/payable_report'; ?>" class="none new">Payable Report</a>
    <a href="<?php echo Yii::app()->request->baseUrl . '/supplier/paid_report'; ?>" class="none new">Paid Report</a>  
    <a href="<?php echo Yii::app()->request->baseUrl . '/supplier/cheque_payment'; ?>" class="none new">Cheque Issued</a>  
    <a href="<?php echo Yii::app()->request->baseUrl . '/supplier/purchase_return'; ?>" class="none new">Purchase Return</a>
    <a href="<?php echo Yii::app()->request->baseUrl . '/supplier/purchase_return_report'; ?>" class="none new">Purchase Return Report</a>  
</div>